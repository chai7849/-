import React from 'react';
import { Spinner } from './Spinner';
import { PaintBrushIcon } from './icons/PaintBrushIcon';

export const LoadingPlaceholder: React.FC = () => {
  return (
    <div className="aspect-square w-full max-w-lg mx-auto bg-stone-100/50 border-2 border-dashed border-stone-300 rounded-lg flex flex-col items-center justify-center text-center p-8">
      <div className="relative mb-4">
        <PaintBrushIcon className="w-12 h-12 text-stone-400" />
      </div>
      <Spinner />
      <div className="mt-4">
        <p className="text-lg font-medium text-stone-600">AI 화가가 최고의 구도를 구상하는 중입니다...</p>
        <p className="text-stone-500">잠시만 기다려 주세요.</p>
      </div>
    </div>
  );
};
