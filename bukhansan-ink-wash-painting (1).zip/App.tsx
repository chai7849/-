import React, { useState } from 'react';
import { generateBukhansanPainting } from './services/geminiService';
import { LoadingPlaceholder } from './components/LoadingPlaceholder';
import { MountainIcon } from './components/icons/MountainIcon';
import { PaintBrushIcon } from './components/icons/PaintBrushIcon';
import { DownloadIcon } from './components/icons/DownloadIcon';

function App() {
  const [style, setStyle] = useState('정선');
  const [customPrompt, setCustomPrompt] = useState('');
  const [palette, setPalette] = useState('monochromatic');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    setGeneratedImage(null);

    try {
      const imageUrl = await generateBukhansanPainting(style, customPrompt, palette);
      setGeneratedImage(imageUrl);
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = () => {
    if (generatedImage) {
      const link = document.createElement('a');
      link.href = generatedImage;
      link.download = `bukhansan_${style}_${new Date().toISOString()}.png`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <div className="bg-stone-50 min-h-screen flex flex-col items-center justify-center font-sans text-stone-800 p-4">
      <main className="container mx-auto max-w-4xl bg-white shadow-xl rounded-lg p-8">
        <header className="text-center mb-8">
          <MountainIcon className="w-16 h-16 mx-auto text-stone-700" />
          <h1 className="text-4xl font-bold mt-4">AI 산수화: 북한산</h1>
          <p className="text-stone-500 mt-2">AI로 북한산 인수봉을 주제로 한 아름다운 산수화를 만들어 보세요.</p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Style selection */}
          <div>
            <label htmlFor="style" className="block text-lg font-medium text-stone-700 mb-2">화풍 선택</label>
            <select
              id="style"
              value={style}
              onChange={(e) => setStyle(e.target.value)}
              className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-stone-500 focus:border-stone-500 transition"
            >
              <option value="정선">정선 (진경산수화)</option>
              <option value="김홍도">김홍도 (풍속화)</option>
              <option value="추상화">추상화</option>
              <option value="인상주의">인상주의</option>
              <option value="사실주의">사실주의</option>
              <option value="바로크">바로크 (Baroque)</option>
              <option value="르네상스">르네상스 (Renaissance)</option>
            </select>
          </div>

          {/* Custom prompt */}
          <div>
            <label htmlFor="customPrompt" className="block text-lg font-medium text-stone-700 mb-2">
              추가 요청사항 (선택)
            </label>
            <input
              type="text"
              id="customPrompt"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="예: '가을 단풍이 물든 모습으로'"
              className="w-full p-3 border border-stone-300 rounded-lg focus:ring-2 focus:ring-stone-500 focus:border-stone-500 transition"
            />
          </div>
          
          {/* Palette selection */}
          <div>
            <label className="block text-lg font-medium text-stone-700 mb-2">색감 선택</label>
            <div className="flex space-x-4">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input type="radio" name="palette" value="monochromatic" checked={palette === 'monochromatic'} onChange={(e) => setPalette(e.target.value)} className="form-radio h-5 w-5 text-stone-600 focus:ring-stone-500"/>
                <span>수묵화 (단색)</span>
              </label>
              <label className="flex items-center space-x-2 cursor-pointer">
                <input type="radio" name="palette" value="muted" checked={palette === 'muted'} onChange={(e) => setPalette(e.target.value)} className="form-radio h-5 w-5 text-stone-600 focus:ring-stone-500"/>
                <span>차분한 색감</span>
              </label>
              <label className="flex items-center space-x-2 cursor-pointer">
                <input type="radio" name="palette" value="vibrant" checked={palette === 'vibrant'} onChange={(e) => setPalette(e.target.value)} className="form-radio h-5 w-5 text-stone-600 focus:ring-stone-500"/>
                <span>생동감 있는 색감</span>
              </label>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full flex items-center justify-center bg-stone-700 text-white font-bold py-3 px-6 rounded-lg hover:bg-stone-800 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-stone-500 disabled:bg-stone-400 disabled:cursor-not-allowed transition-colors"
          >
            <PaintBrushIcon className="w-5 h-5 mr-2" />
            {isLoading ? '그림을 생성하는 중...' : '산수화 그리기'}
          </button>
        </form>

        <div className="mt-8 text-center">
          {isLoading && <LoadingPlaceholder />}
          {error && <div className="text-red-600 bg-red-100 border border-red-400 rounded-lg p-4">{error}</div>}
          
          {!isLoading && !error && generatedImage && (
            <div className="relative group">
              <img src={generatedImage} alt="Generated Bukhansan painting" className="rounded-lg shadow-lg mx-auto" />
              <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all flex items-center justify-center">
                <button
                    onClick={handleDownload}
                    className="opacity-0 group-hover:opacity-100 transition-opacity bg-white text-stone-800 font-bold py-3 px-5 rounded-lg flex items-center shadow-lg"
                >
                    <DownloadIcon className="w-5 h-5 mr-2" />
                    다운로드
                </button>
              </div>
            </div>
          )}

          {!isLoading && !error && !generatedImage && (
             <div className="aspect-square w-full max-w-lg mx-auto bg-stone-100/50 border-2 border-dashed border-stone-300 rounded-lg flex flex-col items-center justify-center text-center p-8">
                <PaintBrushIcon className="w-16 h-16 text-stone-400 mb-4" />
                <p className="text-lg text-stone-500">이곳에 생성된 산수화가 표시됩니다.</p>
             </div>
          )}
        </div>
      </main>
      <footer className="text-center text-stone-500 text-sm mt-8 pb-4">
        <p>Powered by Google Gemini API</p>
      </footer>
    </div>
  );
}

export default App;
