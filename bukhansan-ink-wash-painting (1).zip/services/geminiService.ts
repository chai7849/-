import { GoogleGenAI, Modality } from "@google/genai";

// Fix: Per Gemini API guidelines, directly use process.env.API_KEY and assume it's available.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateBukhansanPainting(style: string, customPrompt: string, palette: string): Promise<string> {
  try {
    const subject = customPrompt.trim() || '북한산 인수봉';

    let styleDescription = `${style} 화풍`;
    let artisticDirection = '고요한 분위기와 함께 대상의 아름다움을 섬세하게 표현해줘.'; // Default direction

    switch (style) {
      case '정선':
        styleDescription = '한국 진경산수화의 대가, 겸재 정선의 화풍';
        artisticDirection = "웅장한 바위의 질감을 표현하는 '부벽준' 같은 강렬한 붓 터치를 사용하고, 먹의 농담을 활용한 흑백 대비를 통해 실제 경치의 아름다움을 담아내 줘. 여백의 미를 살리는 것이 매우 중요해.";
        break;
      case '김홍도':
        styleDescription = '조선시대 풍속화의 대가, 단원 김홍도의 화풍';
        artisticDirection = "간결하면서도 힘 있는 선으로 인물들의 생동감 넘치는 표정과 동작을 포착하고, 서민들의 삶에 대한 따뜻한 시선을 담아 해학적인 분위기를 연출해줘. 그림 속에 등산객이나 작은 동물 같은 요소를 넣어 이야기를 만들어줘.";
        break;
      case '추상화':
        styleDescription = '추상주의 스타일';
        artisticDirection = "칸딘스키처럼 역동적인 에너지와 감정을 색과 선으로 표현하거나, 몬드리안처럼 기하학적인 형태로 본질을 탐구해줘. 구체적인 묘사 대신 산의 웅장함과 기운을 추상적으로 표현하는 데 집중해줘.";
        break;
      case '인상주의':
        styleDescription = '클로드 모네와 같은 인상주의 화풍';
        artisticDirection = "시시각각 변하는 빛의 인상을 포착하는 데 집중해줘. 짧고 부서지는 듯한 붓 터치와 색채 분할 기법을 사용해 햇빛이 반사되는 바위와 나뭇잎의 생동감 넘치는 분위기를 만들어줘.";
        break;
      case '사실주의':
        styleDescription = '극사실주의 또는 하이퍼리얼리즘 스타일';
        artisticDirection = "사진보다 더 사진처럼, 바위의 미세한 질감, 나뭇잎의 잎맥, 빛의 굴절까지 정밀하게 묘사해줘. 모든 디테일을 극도로 세밀하게 표현하여 현실감을 극대화해줘.";
        break;
      case '바로크':
        styleDescription = '카라바조나 렘브란트 같은 바로크 스타일';
        artisticDirection = "빛과 어둠의 극적인 대비(키아로스쿠로)를 사용하여 감정적이고 격렬한 분위기를 연출해줘. 사선 구도를 활용해 역동적인 움직임을 강조하고, 풍부하고 깊은 색채로 웅장함을 표현해줘.";
        break;
      case '르네상스':
        styleDescription = '레오나르도 다빈치나 라파엘로 같은 르네상스 시대의 화풍';
        artisticDirection = "원근법을 철저히 적용하고 안정적인 삼각형 구도를 사용하여 조화와 균형을 추구해줘. 스푸마토 기법으로 부드러운 명암을 표현하고, 이상적인 아름다움을 담아 명확하고 사실적인 형태로 그려줘.";
        break;
    }

    let paletteDescription = '';
    switch (palette) {
      case 'vibrant':
        paletteDescription = '전체적으로 생동감 있고 풍부한 색감';
        break;
      case 'muted':
        paletteDescription = '차분하고 절제된 톤의 색감';
        break;
      case 'monochromatic':
      default:
        paletteDescription = '전통 수묵화처럼 단색조의 깊이감 있는 색감';
        break;
    }

    const prompt = `${subject}을(를) 주제로 그림을 그려줘. 화풍은 ${styleDescription}으로 하고, ${paletteDescription}을 사용해줘. ${artisticDirection}`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: prompt,
          },
        ],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
          const base64ImageBytes: string = part.inlineData.data;
          const mimeType = part.inlineData.mimeType;
          return `data:${mimeType};base64,${base64ImageBytes}`;
        }
    }

    // Fix: Throw a more user-friendly error message when no image is found in the response.
    throw new Error("AI가 이미지를 생성하지 못했습니다. 다른 스타일로 다시 시도해 보세요.");

  } catch (error: any) {
    console.error("Gemini API 이미지 생성 오류:", error);
    
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
        throw new Error("네트워크에 연결되어 있지 않습니다. 인터넷 연결을 확인해 주세요.");
    }

    // Fix: Propagate the specific user-friendly error from the try block.
    if (error.message === "AI가 이미지를 생성하지 못했습니다. 다른 스타일로 다시 시도해 보세요.") {
      throw error;
    }

    const message = error.message?.toLowerCase() || '';

    if (message.includes('api key not valid')) {
        throw new Error("API 키가 유효하지 않습니다. 관리자에게 문의하세요.");
    }
    
    if (message.includes('quota') || message.includes('rate limit') || (error.status === 429)) {
        throw new Error("요청 횟수가 너무 많습니다. 잠시 후 다시 시도해 주세요.");
    }

    if (message.includes('invalid argument') || message.includes('bad request')) {
        throw new Error("잘못된 요청입니다. 선택한 옵션을 확인해 주세요.");
    }
    
    if (message.includes('no image data found')) {
        throw new Error("AI가 이미지를 생성하지 못했습니다. 다른 스타일로 다시 시도해 보세요.");
    }

    throw new Error("그림을 생성하는 중 서버에 문제가 발생했습니다. 잠시 후 다시 시도해 주세요.");
  }
}